/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <strings.h>
#include <ctype.h>
//#include "DWIN.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
DMA_HandleTypeDef hdma_usart3_rx;

/* USER CODE BEGIN PV */
uint8_t rx_buffer[100];
uint8_t raw_preset_data[100];
uint8_t received_frame[100];
uint8_t received_data[100];
bool WeatherDataRequest_flag = false;
HAL_StatusTypeDef status;
uint8_t received_datalength = 0;
char dummy_buffer[64];
uint32_t Cycle_Time = 0;

uint32_t sum = 0;
uint32_t analog_Pot = 0;
float NoLoad_adc_Value = 0;
float fullLoad_adc_value = 0;

float acs712_volt_value;
uint32_t start_time;
bool startFullLoadTimer = false;
uint32_t fullLoadTimerStart;
LoadState state = STATE_WAIT_NOLOAD;
uint32_t stateStartTime;
static bool start_receive = true;
int i = 0;
int m = 0;
uint8_t uart3_rx_byte = 0;
char *startPtr = NULL;
bool baudrateChanged_flag = false;
char extracted[25];  // 24 chars + '\0'
int j = 0;
uint16_t ADCSamples[1000];
uint8_t sample_data[100];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */
typedef struct {
    float wind_velocity;
    int wind_direction;
    float temperature;
} WeatherData;

WeatherData Anemometer_param;
typedef struct
{
	uint16_t device_ID;
	uint32_t device_BaudRate;
	uint8_t duplex_mode;
} AnemometerPresetValues;
AnemometerPresetValues Device_defaultValues;

void Get_Data_from_Anemometer(uint8_t *,uint8_t *,uint16_t ,uint8_t *);


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
// Custom strstr implementation
char* my_strstr(const char *haystack, const char *needle)
{
    if (!*needle) return (char *)haystack; // if needle is empty, return haystack

    for (const char *p = haystack; *p; p++)
    {
        const char *h = p;
        const char *n = needle;

        while (*h && *n && (*h == *n))
        {
            h++;
            n++;
        }

        if (!*n)   // reached end of needle → match found
            return (char *)p;
    }
    return NULL;  // no match
}
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

// Helper function: reverse a string
void reverse(char* str, int len) {
    int i = 0, j = len - 1;
    while (i < j) {
        char temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }
}

// Helper function: integer to string
int intToStr(int x, char str[], int d) {
    int i = 0;
    if (x == 0) {
        str[i++] = '0';
    } else {
        while (x) {
            str[i++] = (x % 10) + '0';
            x /= 10;
        }
    }

    // If number of digits is less than requested, add leading 0s
    while (i < d) {
        str[i++] = '0';
    }

    reverse(str, i);
    str[i] = '\0';
    return i;
}

// ftoa: convert float n to string with "afterpoint" digits after decimal
void ftoa(float n, char* res, int afterpoint) {
    // Handle negative numbers
    int i = 0;
    if (n < 0) {
        res[i++] = '-';
        n = -n;
    }

    // Extract integer part
    int ipart = (int)n;

    // Extract floating part
    float fpart = n - (float)ipart;

    // Convert integer part to string
    i += intToStr(ipart, res + i, 0);

    // If decimal digits required
    if (afterpoint > 0) {
        res[i] = '.'; // add dot
        fpart = fpart * pow(10, afterpoint);
        intToStr((int)(fpart + 0.5f), res + i + 1, afterpoint); // rounding
    }
}

void extractBRFrame(char *rx_buffer)
{
    char *start = my_strstr(rx_buffer, "!");      // find first '!'
    while (start != NULL)
    {
        // Look for CRLF after this '!'
        char *end = my_strstr(start, "\r\n");
        if (end == NULL) break;   // no complete frame

        int len = end - start;    // length of this frame (without CRLF)
        if (len > 0 && len < 32)  // safe length
        {
            char extracted[32];
            strncpy(extracted, start, len);
            extracted[len] = '\0';   // null terminate

            // Check if frame contains "BR"
            if (my_strstr(extracted, "BR") != NULL)
            {
                // Found the BR frame → transmit or process
                HAL_UART_Transmit(&huart1, (uint8_t *)extracted, strlen(extracted), 1000);
                HAL_UART_Transmit(&huart1, (uint8_t *)"\r\n", 2, 1000);
            }
        }

        start = my_strstr(end, "!");  // look for next frame
    }
}

int my_atoi(const char *str)
{
    int result = 0;
    int sign = 1;

    // Skip leading spaces
    while (*str == ' ') str++;

    // Handle sign
    if (*str == '-') {
        sign = -1;
        str++;
    } else if (*str == '+') {
        str++;
    }

    // Convert digits to integer
    while (*str >= '0' && *str <= '9') {
        result = result * 10 + (*str - '0');
        str++;
    }

    return sign * result;
}

float my_atof(const char *str)
{
    float result = 0.0f;
    float fraction = 0.0f;
    float divisor = 10.0f;
    int sign = 1;

    // Skip leading spaces
    while (*str == ' ') str++;

    // Handle sign
    if (*str == '-') {
        sign = -1;
        str++;
    } else if (*str == '+') {
        str++;
    }

    // Process integer part
    while (*str >= '0' && *str <= '9') {
        result = result * 10.0f + (*str - '0');
        str++;
    }

    // Process fractional part
    if (*str == '.') {
        str++; // Skip '.'
        while (*str >= '0' && *str <= '9') {
            fraction += (*str - '0') / divisor;
            divisor *= 10.0f;
            str++;
        }
    }

    return sign * (result + fraction);
}
int is_valid_float(const char *str) {
    char *endptr;
    strtof(str, &endptr);
    return (endptr != str && *endptr == '\0');
}

int is_valid_int(const char *str) {
    char *endptr;
    strtol(str, &endptr, 10);
    return (endptr != str && *endptr == '\0');
}

void Parse_Anemometer_Frame(uint8_t *frame, WeatherData *data)
{
    const char *start = strchr(frame, 0x02); // Find <STX>

    if (start != NULL) {
        // Skip <STX>
        start++;

        // Make a copy of the rest of the string for tokenizing
        char temp_buffer[64];
        strncpy(temp_buffer, start, sizeof(temp_buffer) - 1);
        temp_buffer[sizeof(temp_buffer) - 1] = '\0';

        // Tokenize based on space
        char *token = strtok(temp_buffer, " ");
        int field = 0;

        while (token != NULL && field < 3) {
            switch (field) {
                case 0:
                    if (!is_valid_float(token)) return 0; // Reject if not float
                	memset(dummy_buffer,0,sizeof(dummy_buffer));
//                	sprintf(dummy_buffer,"Wind Velocity -> %s m/s ",token);
					sprintf(dummy_buffer,"%s",token);
					SendTextToDWIN(0x6000, dummy_buffer);

//					HAL_UART_Transmit(&huart1, (uint8_t *)dummy_buffer, strlen(dummy_buffer), 1000);
                    data->wind_velocity = strtof(token, NULL);
//					sprintf(dummy_buffer,"%.2f",data->wind_velocity);
//					SendTextToDWIN(0x6000, dummy_buffer);
                    break;
                case 1:
                    if (!is_valid_int(token)) return 0; // Reject if not int
                	memset(dummy_buffer,0,sizeof(dummy_buffer));
////                	sprintf(dummy_buffer,"Wind Direction -> %s ° ",token);
//					HAL_UART_Transmit(&huart1, (uint8_t *)dummy_buffer, strlen(dummy_buffer), 1000);
					sprintf(dummy_buffer,"%s",token);
					SendTextToDWIN(0x6010, dummy_buffer);

                    data->wind_direction = atoi(token);
                    break;
                case 2:
                    if (!is_valid_float(token)) return 0; // Reject if not float
                	memset(dummy_buffer,0,sizeof(dummy_buffer));
//                	sprintf(dummy_buffer,"Temperature -> %s °C\n",token);
//					HAL_UART_Transmit(&huart1, (uint8_t *)dummy_buffer, strlen(dummy_buffer), 1000);
					sprintf(dummy_buffer,"%s",token);
					SendTextToDWIN(0x6020, dummy_buffer);

                	data->temperature = strtof(token, NULL);
                    break;
            }
            field++;
            token = strtok(NULL, " ");
        }
    }
}

float convert_ADC_to_Volt(uint32_t adc_value)
{
	return (((float)adc_value/4095)*3.333 + 0.004);
}

int setUartFromBRCode(int brCode)
{
    uint32_t baud      = 9600; // default
    uint32_t wordLen   = UART_WORDLENGTH_8B;
    uint32_t parity    = UART_PARITY_NONE;
    uint32_t stopBits  = UART_STOPBITS_1;

    switch (brCode)
    {
        case 2: // 1200 8N1
            baud = 1200;
            wordLen = UART_WORDLENGTH_8B;
            parity = UART_PARITY_NONE;
            stopBits = UART_STOPBITS_1;
            break;

        case 3: // 2400 8N1
            baud = 2400;
            wordLen = UART_WORDLENGTH_8B;
            parity = UART_PARITY_NONE;
            stopBits = UART_STOPBITS_1;
            break;

        case 4: // 4800 8N1
            baud = 4800;
            wordLen = UART_WORDLENGTH_8B;
            parity = UART_PARITY_NONE;
            stopBits = UART_STOPBITS_1;
            break;
        case 5: // 9600 8N1
            baud = 9600;
            wordLen = UART_WORDLENGTH_8B;
            parity = UART_PARITY_NONE;
            stopBits = UART_STOPBITS_1;
            break;
        case 6: // 19200 8N1
            baud = 19200;
            wordLen = UART_WORDLENGTH_8B;
            parity = UART_PARITY_NONE;
            stopBits = UART_STOPBITS_1;
            break;
        case 7: // 38400 8N1
            baud = 38400;
            wordLen = UART_WORDLENGTH_8B;
            parity = UART_PARITY_NONE;
            stopBits = UART_STOPBITS_1;
            break;
        case 8: // 57600 8N1
            baud = 57600;
            wordLen = UART_WORDLENGTH_8B;
            parity = UART_PARITY_NONE;
            stopBits = UART_STOPBITS_1;
            break;
        case 9: // 115200 8N1
            baud = 115200;
            wordLen = UART_WORDLENGTH_8B;
            parity = UART_PARITY_NONE;
            stopBits = UART_STOPBITS_1;
            break;
        case 10: // 1200 8N1
            baud = 1200;
            wordLen = UART_WORDLENGTH_7B;   // requires HAL supporting 7-bit
            parity = UART_PARITY_EVEN;
            stopBits = UART_STOPBITS_1;
            break;
        case 11: // 2400 8N1
            baud = 2400;
            wordLen = UART_WORDLENGTH_7B;   // requires HAL supporting 7-bit
            parity = UART_PARITY_EVEN;
            stopBits = UART_STOPBITS_1;
            break;
        case 12: // 4800 8N1
            baud = 4800;
            wordLen = UART_WORDLENGTH_7B;   // requires HAL supporting 7-bit
            parity = UART_PARITY_EVEN;
            stopBits = UART_STOPBITS_1;
            break;
        case 13: // 9600 8N1
            baud = 9600;
            wordLen = UART_WORDLENGTH_7B;   // requires HAL supporting 7-bit
            parity = UART_PARITY_EVEN;
            stopBits = UART_STOPBITS_1;
            break;
        case 14: // 19200 8N1
            baud = 19200;
            wordLen = UART_WORDLENGTH_7B;   // requires HAL supporting 7-bit
            parity = UART_PARITY_EVEN;
            stopBits = UART_STOPBITS_1;
            break;
        case 15: // 38400 8N1
            baud = 38400;
            wordLen = UART_WORDLENGTH_7B;   // requires HAL supporting 7-bit
            parity = UART_PARITY_EVEN;
            stopBits = UART_STOPBITS_1;
            break;
        case 16: // 1200 8N1
            baud = 57600;
            wordLen = UART_WORDLENGTH_7B;   // requires HAL supporting 7-bit
            parity = UART_PARITY_EVEN;
            stopBits = UART_STOPBITS_1;
            break;
        case 17: // 115200 7E1
            baud = 115200;
            wordLen = UART_WORDLENGTH_7B;   // requires HAL supporting 7-bit
            parity = UART_PARITY_EVEN;
            stopBits = UART_STOPBITS_1;
            break;

        default:
            return -1; // unsupported BR code
    }

    // Reconfigure UART
    huart3.Init.BaudRate   = baud;
    huart3.Init.WordLength = wordLen;
    huart3.Init.Parity     = parity;
    huart3.Init.StopBits   = stopBits;


//    huart3.Init.BaudRate = 9600;
//    huart3.Init.WordLength = UART_WORDLENGTH_8B;
//    huart3.Init.Parity = UART_PARITY_NONE;
//    huart3.Init.StopBits = UART_STOPBITS_1;

    char buffer[50];
    sprintf(buffer,(uint8_t*)"ID :%d, BR :%ld,%s",Device_defaultValues.device_ID,baud,"Half Duplex");
    SendTextToDWIN(0x7000, buffer);


    if (HAL_UART_Init(&huart3) != HAL_OK)
    {
        return -2; // re-init failed
    }

    return 0; // success
}
bool get_ID_and_Frame(char *frame,AnemometerPresetValues *deviceValues)
{
    char *start = frame;
    char buffer[100];

    while ((start = strchr(start, '!')) != NULL)   // find each frame starting with '!'
    {
        // each frame format: !xxCCyyyyy\r\n (12 chars minimum)
        if (strlen(start) < 12) {
            return false; // incomplete frame
        }

        char id[3] = {0};
        char cmd[3] = {0};
        char value[6] = {0};

        strncpy(id,   &start[1], 2);  // ID
        strncpy(cmd,  &start[3], 2);  // Command
        strncpy(value,&start[5], 5);  // Value

        int id_num = atoi(id);
        int val  = atoi(value);
        deviceValues->device_ID = id_num;


        // --- Print results over UART ---
        sprintf(buffer,"ID: %d\r\n", id_num);
        HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 100);


        sprintf(buffer,"Command: %s\r\n", cmd);
        HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 100);

        if (strcmp(cmd, "BR") == 0) {
            sprintf(buffer,"Baud Rate: %d\r\n", val);
            deviceValues->device_BaudRate = val;
            HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 100);

        }
        else if (strcmp(cmd, "DM") == 0) {
            if (val == 0)
            {
                sprintf(buffer,"Duplex Mode: Half Duplex\r\n");
                HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 100);

                sprintf(buffer,(uint8_t*)"ID :%d, BR :%d,%s",deviceValues->device_ID,deviceValues->device_BaudRate,"Half Duplex");
                SendTextToDWIN(0x7000, buffer);
            }
            else if (val == 1)
                sprintf(buffer,"Duplex Mode: Full Duplex\r\n");
            else
                sprintf(buffer,"Duplex Mode: Unknown (%d)\r\n", val);

            HAL_UART_Transmit(&huart2, (uint8_t*)buffer, strlen(buffer), 100);
        }

        // move pointer to next frame (after \r\n)
        char *next = strstr(start, "\r\n");
        if (next == NULL) break;
        start = next + 2;
    }

    return true;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_TIM3_Init();
  MX_ADC1_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  baudrateChanged_flag = false;
  WeatherDataRequest_flag = false;

  huart3.Init.BaudRate = 9600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.StopBits = UART_STOPBITS_1;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
			Error_Handler();
  }

	HAL_GPIO_WritePin(RS485_EN_GPIO_Port, RS485_EN_Pin, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(RS485_SELECT_GPIO_Port, RS485_SELECT_Pin, GPIO_PIN_RESET);
//	setUartFromBRCode(5); // Initially set the Baud Rate for 9600

	    char buffer[50];
	    strcpy(buffer, "ID :--, BR :--");
//	    sprintf(buffer,);
	    SendTextToDWIN(0x7000, "                                          ");

	    SendTextToDWIN(0x7000, buffer);





//	__HAL_UART_DISABLE_IT(&huart3,UART_IT_IDLE);
	  HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);

	__HAL_UART_ENABLE_IT(&huart3,UART_IT_IDLE);
	page_switch(0);
	HAL_Delay(2000);
	page_switch(1);
//	HAL_ADC_Start_DMA(&hadc1, ADCSamples, 100);
//	memset(raw_preset_data,0,100);
	  char buf[3];

	  HAL_TIM_Base_Start_IT(&htim3);
//	  if(__HAL_RCC_GET_FLAG(RCC_FLAG_IWDGRST)!=RESET)
//	  {
//			HAL_UART_Transmit(&huart2, "Load Disconnected\r\n", 19, 100);
//		  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_SET);
//	  }
//	  else
//	  {
//		  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);
//
//	  }

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  // Note the timing Now
//	  uint32_t t_start = HAL_GetTick();
//
//		Get_Data_from_Anemometer((uint8_t *)"00", (uint8_t *)"TR3", 3, (uint8_t *)received_frame);
//
//		HAL_Delay(500);
//		uint32_t t_end = HAL_GetTick();
//		Cycle_Time = t_end - t_start;
//		HAL_GPIO_WritePin(RS485_EN_GPIO_Port, RS485_EN_Pin, GPIO_PIN_RESET);
//		HAL_GPIO_WritePin(RS485_SELECT_GPIO_Port, RS485_SELECT_Pin, GPIO_PIN_RESET);


//	  if(baudrateChanged_flag)
//	  {
////		  sprintf(buf,"%d",Device_defaultValues.device_ID);
//		  itoa((int )Device_defaultValues.device_ID,buf,10);
//		 Get_Data_from_Anemometer("00", (uint8_t *)"TR3", 3, (uint8_t *)received_frame);
//		  WeatherDataRequest_flag = false;
//	  }
//	  sum = 0;
//	  for (int i = 0; i < 4000; i++)
//	  {
//
//	  // once
////		  acs712_volt_value = 0;
//
//		  HAL_ADC_Start(&hadc1);
//		  HAL_ADC_PollForConversion(&hadc1, 1000);
//
//	  // Wait until conversion done
//		  sum+= HAL_ADC_GetValue(&hadc1);
//	  // Accumulate readings
//		  HAL_ADC_Stop(&hadc1);
//	  }
//	  // HAL_Delay(5);
//
//	  analog_Pot = sum / 4000; // Average result
//	  sum = 0;
//	  acs712_volt_value = convert_ADC_to_Volt(analog_Pot);
//
//					switch(state)
//					{
//						case STATE_WAIT_NOLOAD:
//							if (HAL_GetTick() - stateStartTime >= 6000)
//							{
//								NoLoad_adc_Value = acs712_volt_value;
//								memset(dummy_buffer,0,sizeof(dummy_buffer));
//								char buffer[6];
//								ftoa(NoLoad_adc_Value, buffer, 2);
//								sprintf(dummy_buffer,"\nNo Load ADC Volt Value : %s",buffer);
//
//								HAL_UART_Transmit(&huart2, dummy_buffer, strlen(dummy_buffer), 500);
//
////								trigger_once = false;
//					//            memset(rx_buffer, 0, sizeof(rx_buffer));
////								memset(raw_preset_data,0,sizeof(raw_preset_data));
//
//
//								state = STATE_WAIT_LOAD_DROP;
//							}
//							break;
//
//						case STATE_WAIT_LOAD_DROP:
//							if ((NoLoad_adc_Value - acs712_volt_value) >= 0.005)
//							{
////								m = 0;
////								HAL_GPIO_WritePin(RS485_EN_GPIO_Port, RS485_EN_Pin, GPIO_PIN_RESET);
////								HAL_GPIO_WritePin(RS485_SELECT_GPIO_Port, RS485_SELECT_Pin, GPIO_PIN_RESET);
//								HAL_UART_Transmit(&huart2, "\nLoad Connected\r\n", 17, 100);
////								start_receive = true;
//								stateStartTime = HAL_GetTick();
////								int j = 0;
////								memset(received_frame,0,sizeof(received_frame));
//					//        	HAL_UART_Transmit(&huart1, rx_buffer, i, 1000);
//
//								// Clear buffer/index for fresh receive
//					//            i = 0;
////					            memset(raw_preset_data, 0, sizeof(raw_preset_data));
//
//								state = STATE_WAIT_FULLLOAD_CAPTURE;
//							}
//							break;
//
//						case STATE_WAIT_FULLLOAD_CAPTURE:
////							memset(raw_preset_data,0,100);
//							if ((HAL_GetTick() - stateStartTime) >= 4000)
//							{
//								fullLoad_adc_value = acs712_volt_value;
//								memset(dummy_buffer,0,sizeof(dummy_buffer));
//								char buffer[6];
//								ftoa(fullLoad_adc_value, buffer, 2);
//								sprintf(dummy_buffer,"\nFull Load ADC Volt Value : %s",buffer);
//
//								HAL_UART_Transmit(&huart2, dummy_buffer, strlen(dummy_buffer), 200);
//
//
//								state = STATE_WAIT_LOAD_DISCONNECT;
//							}
//							break;
//
//						case STATE_WAIT_LOAD_DISCONNECT:
//							if ((acs712_volt_value - fullLoad_adc_value) >= 0.005)
//							{
////								HAL_Delay(1250);
//								stateStartTime = HAL_GetTick();
//								state = STATE_WAIT_NOLOAD_AFTER_DISCONNECT;
//							}
//							break;
//
//						case STATE_WAIT_NOLOAD_AFTER_DISCONNECT:
//							if (HAL_GetTick() - stateStartTime >= 3000)
//							{
//								float newNoLoad = acs712_volt_value;
//								// Do Software Reset
//								memset(raw_preset_data,0,sizeof(raw_preset_data));
//								setUartFromBRCode(5);
//								Device_defaultValues.device_ID = 0;
//								Device_defaultValues.device_BaudRate = 0;
//								baudrateChanged_flag = false;
//								NoLoad_adc_Value = newNoLoad;
//
//								HAL_TIM_Base_Stop_IT(&htim3);
////								HAL_Delay(4500);
////								NVIC_SystemReset();
//
//
////								preset_data_Received = false;
//
//								state = STATE_WAIT_LOAD_DROP;
//							}
//							break;
//	  }

	//Note the timing Just now

					if(start_receive == true)
					{
//						HAL_UART_Receive(&huart3, sample_data, 100, 1000);
//						HAL_UART_Transmit(&huart1, sample_data, 100, 1000);
//						  HAL_TIM_Base_Start_IT(&htim3);

						m = 0;
						while(HAL_UART_Receive(&huart3, &uart3_rx_byte, 1, 300) == HAL_OK)
						{
//							HAL_UART_Transmit(&huart1, &sample_data[m], 1, 1000);
							if (isalnum(uart3_rx_byte) || uart3_rx_byte == '!' || uart3_rx_byte == '\r' || uart3_rx_byte == '\n' || uart3_rx_byte == ' ')
							{
								raw_preset_data[m] = uart3_rx_byte;
								HAL_UART_Transmit(&huart2, &raw_preset_data[m], 1, 100);
								m++;
								if(m>60)
								{
						            char *startPtr = my_strstr(raw_preset_data, "SONIC");
						            if(startPtr!=NULL)
						            {
											if (strlen(startPtr) >= 43)
											{
												strncpy(extracted, &startPtr[19], 24);
												extracted[24] = '\0';
										//                    HAL_UART_Transmit(&huart1, (uint8_t *)extracted, strlen(extracted), 1000);
												get_ID_and_Frame(extracted,&Device_defaultValues);

													setUartFromBRCode(Device_defaultValues.device_BaudRate);
													baudrateChanged_flag = true;
													HAL_UART_Transmit(&huart2, "Baud Rate Changed\r\n", 19, 100);

	//													getOnceFlag = false;
												memset(extracted, 0, sizeof(extracted));
												memset(raw_preset_data,0,sizeof(received_data));
												startPtr = NULL;
												m = 0;
												start_receive = false;
//												  HAL_TIM_Base_Start_IT(&htim3);

//										        break;
											}
						            }
//								            rx_buffer[i] = '\0';   // null terminate
							}
							uart3_rx_byte = 0;


							}
						 }
					}


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_47CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 39999;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 0;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 19200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 19200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 19200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 2, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, RS485_SELECT_Pin|RS485_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : RS485_SELECT_Pin RS485_EN_Pin */
  GPIO_InitStruct.Pin = RS485_SELECT_Pin|RS485_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/*
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
	  for (int i = 0; i < 100; i++)
	  {

//	      HAL_ADC_Start(&hadc2);
//	      HAL_ADC_PollForConversion(&hadc2, 1000); // Wait until conversion done
//	      sum += HAL_ADC_GetValue(&hadc2);         // Accumulate readings
//	      HAL_ADC_Stop(&hadc2);
//	      HAL_Delay(5);
		  sum += ADCSamples[i];
	  }

		  analog_Pot = sum / 100; // Average result
		sum = 0;
		memset(ADCSamples, 0, sizeof(ADCSamples));
		acs712_volt_value = convert_ADC_to_Volt(analog_Pot);
		analog_Pot = 0;


}
*/
void Get_Data_from_Anemometer(uint8_t *id, uint8_t *command, uint16_t command_size, uint8_t *received_Frame)
{
    uint8_t buffer[64] = {0};      // Command buffer
//    uint8_t rx_buffer[64] = {0};   // Receive buffer
    int i = 0, j = 0;

    // Compose command: e.g., "00TR3\r"
    sprintf((char *)buffer, "\r%s%s\r", id, command);

    // Check for weather data command like "TR"
//    if (buffer[4] == 'T' && buffer[5] == 'R') {
//        WeatherDataRequest_flag = true;
//    }
//    HAL_Delay(250);

    // Enable RS485 Transmission

	HAL_GPIO_WritePin(RS485_EN_GPIO_Port, RS485_EN_Pin, GPIO_PIN_SET);
	HAL_GPIO_WritePin(RS485_SELECT_GPIO_Port, RS485_SELECT_Pin, GPIO_PIN_SET);

    // Transmit command
//	HAL_UART_Transmit(&huart3, "00RD250\r", 8, 1000);
    HAL_UART_Transmit(&huart3, buffer, strlen((char *)buffer), 10);

    // Disable RS485 Transmission (Enable Receive)
    HAL_GPIO_WritePin(RS485_EN_GPIO_Port, RS485_EN_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(RS485_SELECT_GPIO_Port, RS485_SELECT_Pin, GPIO_PIN_RESET);
//    HAL_Delay(2);
    // Clear and start receiving
    memset(rx_buffer, 0, sizeof(rx_buffer));
    __HAL_UART_ENABLE_IT(&huart3, UART_IT_IDLE);

    HAL_UART_Receive_DMA(&huart3, rx_buffer, 30);

    // Enable idle line interrupt to detect end of frame
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM3)
	{
		__HAL_TIM_SET_AUTORELOAD(&htim3,500);
//		HAL_GPIO_TogglePin(LD2_GPIO_Port, LD2_Pin);
//		  HAL_UART_Transmit(&huart1, "Hello Sai!!\n", 12, 1000);
//				HAL_GPIO_WritePin(RS485_EN_GPIO_Port, RS485_EN_Pin, GPIO_PIN_RESET);
//				HAL_GPIO_WritePin(RS485_SELECT_GPIO_Port, RS485_SELECT_Pin, GPIO_PIN_RESET);
		WeatherDataRequest_flag = true;
		char buf[3];
		if(Device_defaultValues.device_ID <10)
		{
		sprintf(buf,"%d%d",0,Device_defaultValues.device_ID);
		}
		else if(Device_defaultValues.device_ID>=10)
		{
			sprintf(buf,"%d",Device_defaultValues.device_ID);
		}
//			buf[2] = '\0';
//				Get_Data_from_Anemometer(buf, (uint8_t *)"TR3", 3, (uint8_t *)received_frame);

		Get_Data_from_Anemometer((uint8_t *)buf, (uint8_t *)"TR3", 3, (uint8_t *)received_frame);

	}
}
void USER_UART_IRQHandler(UART_HandleTypeDef *huart)
{
	if(USART3 == huart3.Instance)
	{
		if(__HAL_UART_GET_FLAG(&huart3,UART_FLAG_IDLE)!=RESET)
		{
			__HAL_UART_CLEAR_IDLEFLAG(&huart3);
			USER_UART_IDLECallback(huart);
		}
	}
}
void USER_UART_IDLECallback(UART_HandleTypeDef *huart)
{
	HAL_UART_DMAStop(&huart3);
	uint8_t data_length = 30 - __HAL_DMA_GET_COUNTER(&hdma_usart3_rx);
	int i = 0;
	int j = 0;
	received_datalength = data_length;
if(received_datalength>2)
{
		if(rx_buffer[0]!=0x02)
		{
			received_datalength = 0;

			char buf[3];
			if(Device_defaultValues.device_ID <10)
			{
			sprintf(buf,"%d%d",0,Device_defaultValues.device_ID);
			}
			else if(Device_defaultValues.device_ID>=10)
			{
				sprintf(buf,"%d",Device_defaultValues.device_ID);
			}
	//			buf[2] = '\0';
	//				Get_Data_from_Anemometer(buf, (uint8_t *)"TR3", 3, (uint8_t *)received_frame);

			Get_Data_from_Anemometer((uint8_t *)buf, (uint8_t *)"TR3", 3, (uint8_t *)received_frame);
		}
		//sprintf(text,"Received Data :%s, Received DataLength :%d\n",rx_buffer,data_length);
		if (rx_buffer[0] == 0x02)
		{
			for (i = 0; i < data_length; i++)
			{
					received_frame[j++] = rx_buffer[i];

			}

			// Ensure 0x03 was found and add it to the frame
			if (rx_buffer[i] == 0x03)
			{
				received_frame[j++] = rx_buffer[i];  // Add 0x03
			}

			received_frame[j] = '\0';  // Null-terminate if needed (for string printing)
//			WeatherDataRequest_flag = false;
			Parse_Anemometer_Frame(received_frame, &Anemometer_param);

			    __HAL_UART_DISABLE_IT(&huart3, UART_IT_IDLE);


		}
//		WeatherDataRequest_flag = false;

//	HAL_UART_Transmit(&huart1, received_frame, strlen(received_frame), 30);
//	j=0;
//	i=0;
	memset(rx_buffer,0,data_length);
	memset(received_frame,0,j);

//		memcpy(received_frame, rx_buffer, data_length);/
	data_length = 0;
	received_datalength = 0;
	j = 0;

}
else
{
	received_datalength = 0;

	char buf[3];
	if(Device_defaultValues.device_ID <10)
	{
		sprintf(buf,"%d%d",0,Device_defaultValues.device_ID);
	}
	else if(Device_defaultValues.device_ID>=10)
	{
		sprintf(buf,"%d",Device_defaultValues.device_ID);
	}
//			buf[2] = '\0';
//				Get_Data_from_Anemometer(buf, (uint8_t *)"TR3", 3, (uint8_t *)received_frame);

	Get_Data_from_Anemometer((uint8_t *)buf, (uint8_t *)"TR3", 3, (uint8_t *)received_frame);


}
//__HAL_UART_DISABLE_IT(&huart3,UART_IT_IDLE);

//Get_Data_from_Anemometer((uint8_t *)"00", (uint8_t *)"TR3", 3, (uint8_t *)received_frame);



//	__HAL_UART_DISABLE_IT(&huart3,UART_IT_IDLE);



//	HAL_UART_Receive_DMA(&huart3, rx_buffer, 255);


}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
