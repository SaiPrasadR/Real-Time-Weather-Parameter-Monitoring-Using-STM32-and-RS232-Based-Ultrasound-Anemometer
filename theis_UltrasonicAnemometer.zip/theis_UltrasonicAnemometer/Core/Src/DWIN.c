/*
 * DWIN.c
 *
 *  Created on: Jul 28, 2025
 *      Author: sakth
 */
#include "DWIN.h"


// Adjust based on your UART handle
extern UART_HandleTypeDef *huart1;

void page_switch(uint16_t page_ID)
{
//	page_ID = DwinPageSwitch_Command[]
	DwinPageSwitch_Command[8] = HIGH_BYTE(page_ID);
	DwinPageSwitch_Command[9] = LOW_BYTE(page_ID);
	HAL_UART_Transmit(&huart1, DwinPageSwitch_Command, sizeof(DwinPageSwitch_Command), 1000);

}


void Send2DWIN(uint8_t *data, uint16_t len) {
	HAL_UART_Transmit(&huart1, "                                        ", 40, 100);
    HAL_UART_Transmit(&huart1, data, len, 100);
}

void SendTextToDWIN(uint16_t vpAddr, const char *text) {
    uint8_t packet[100];  // Sufficient for short texts
    uint8_t len = strlen(text);

    // Header
    packet[0] = 0x5A;
    packet[1] = 0xA5;

    // Total length: 3 (cmd + addr + text_len) + text_len + 2 (FF FF)
    packet[2] = 3 + len;

    // Command
    packet[3] = 0x82;

    // Address (high byte first)
    packet[4] = (vpAddr >> 8) & 0xFF;
    packet[5] = vpAddr & 0xFF;

    // Text data
    for (uint8_t i = 0; i < len; i++) {
        packet[6 + i] = text[i];
    }

    // Add FF FF terminator
//    packet[6 + len] = 0xFF;
//    packet[7 + len] = 0xFF;

    // Total size = header (3) + payload
    Send2DWIN(packet, 6 + len);  // = 6 (fixed) + len + 2
}


