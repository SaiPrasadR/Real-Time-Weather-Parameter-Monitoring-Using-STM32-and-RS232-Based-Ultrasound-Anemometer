/*
 * DWIN.h
 *
 *  Created on: Jul 28, 2025
 *      Author: sakth
 */

#ifndef INC_DWIN_H_
#define INC_DWIN_H_

#include <string.h>
#include <stdint.h>
#include "main.h"

uint8_t DwinPageSwitch_Command[] = {0x5A,0xA5,0x07,0x82,0x00,0x84,0x5A,0x01,0x00,0x00};
#define HIGH_BYTE(x)  ((uint8_t)((x) >> 8))
#define LOW_BYTE(x)   ((uint8_t)((x) & 0xFF))

void Send2DWIN(uint8_t *, uint16_t );
void SendTextToDWIN(uint16_t , const char *);


#endif /* INC_DWIN_H_ */
